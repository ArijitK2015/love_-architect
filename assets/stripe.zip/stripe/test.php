<?php

Stripe_Customer Object
(
    [_apiKey:protected] => sk_test_stTzxf7eEurEUSNfFl5QEkJO
    [_values:protected] => Array
        (
            [id] => cus_8g9pWoJfHinm3O
            [object] => customer
            [account_balance] => 0
            [business_vat_id] => 
            [created] => 1466510286
            [currency] => 
            [default_source] => card_18OnVMGpvouH9GI4RujeDvwt
            [delinquent] => 
            [description] => New customer
            [discount] => 
            [email] => 
            [livemode] => 
            [metadata] => Stripe_AttachedObject Object
                (
                    [_apiKey:protected] => sk_test_stTzxf7eEurEUSNfFl5QEkJO
                    [_values:protected] => Array
                        (
                        )

                    [_unsavedValues:protected] => Stripe_Util_Set Object
                        (
                            [_elts:Stripe_Util_Set:private] => Array
                                (
                                )

                        )

                    [_transientValues:protected] => Stripe_Util_Set Object
                        (
                            [_elts:Stripe_Util_Set:private] => Array
                                (
                                )

                        )

                    [_retrieveOptions:protected] => Array
                        (
                        )

                )

            [shipping] => 
            [sources] => Stripe_List Object
                (
                    [_apiKey:protected] => sk_test_stTzxf7eEurEUSNfFl5QEkJO
                    [_values:protected] => Array
                        (
                            [object] => list
                            [data] => Array
                                (
                                    [0] => Stripe_Card Object
                                        (
                                            [_apiKey:protected] => sk_test_stTzxf7eEurEUSNfFl5QEkJO
                                            [_values:protected] => Array
                                                (
                                                    [id] => card_18OnVMGpvouH9GI4RujeDvwt
                                                    [object] => card
                                                    [address_city] => Kolkata
                                                    [address_country] => IN
                                                    [address_line1] => 9th Floor, 4B Ecospace Business Park, Rajarhat
                                                    [address_line1_check] => pass
                                                    [address_line2] => 
                                                    [address_state] => West bengal
                                                    [address_zip] => 700156
                                                    [address_zip_check] => pass
                                                    [brand] => Visa
                                                    [country] => US
                                                    [customer] => cus_8g9pWoJfHinm3O
                                                    [cvc_check] => pass
                                                    [dynamic_last4] => 
                                                    [exp_month] => 1
                                                    [exp_year] => 2017
                                                    [fingerprint] => SukIQ8C0aVLzYZHI
                                                    [funding] => credit
                                                    [last4] => 4242
                                                    [metadata] => Stripe_AttachedObject Object
                                                        (
                                                            [_apiKey:protected] => sk_test_stTzxf7eEurEUSNfFl5QEkJO
                                                            [_values:protected] => Array
                                                                (
                                                                )

                                                            [_unsavedValues:protected] => Stripe_Util_Set Object
                                                                (
                                                                    [_elts:Stripe_Util_Set:private] => Array
                                                                        (
                                                                        )

                                                                )

                                                            [_transientValues:protected] => Stripe_Util_Set Object
                                                                (
                                                                    [_elts:Stripe_Util_Set:private] => Array
                                                                        (
                                                                        )

                                                                )

                                                            [_retrieveOptions:protected] => Array
                                                                (
                                                                )

                                                        )

                                                    [name] => Arijit Modak
                                                    [tokenization_method] => 
                                                )

                                            [_unsavedValues:protected] => Stripe_Util_Set Object
                                                (
                                                    [_elts:Stripe_Util_Set:private] => Array
                                                        (
                                                        )

                                                )

                                            [_transientValues:protected] => Stripe_Util_Set Object
                                                (
                                                    [_elts:Stripe_Util_Set:private] => Array
                                                        (
                                                        )

                                                )

                                            [_retrieveOptions:protected] => Array
                                                (
                                                )

                                        )

                                )

                            [has_more] => 
                            [total_count] => 1
                            [url] => /v1/customers/cus_8g9pWoJfHinm3O/sources
                        )

                    [_unsavedValues:protected] => Stripe_Util_Set Object
                        (
                            [_elts:Stripe_Util_Set:private] => Array
                                (
                                )

                        )

                    [_transientValues:protected] => Stripe_Util_Set Object
                        (
                            [_elts:Stripe_Util_Set:private] => Array
                                (
                                )

                        )

                    [_retrieveOptions:protected] => Array
                        (
                        )

                )

            [subscriptions] => Stripe_List Object
                (
                    [_apiKey:protected] => sk_test_stTzxf7eEurEUSNfFl5QEkJO
                    [_values:protected] => Array
                        (
                            [object] => list
                            [data] => Array
                                (
                                )

                            [has_more] => 
                            [total_count] => 0
                            [url] => /v1/customers/cus_8g9pWoJfHinm3O/subscriptions
                        )

                    [_unsavedValues:protected] => Stripe_Util_Set Object
                        (
                            [_elts:Stripe_Util_Set:private] => Array
                                (
                                )

                        )

                    [_transientValues:protected] => Stripe_Util_Set Object
                        (
                            [_elts:Stripe_Util_Set:private] => Array
                                (
                                )

                        )

                    [_retrieveOptions:protected] => Array
                        (
                        )

                )

        )

    [_unsavedValues:protected] => Stripe_Util_Set Object
        (
            [_elts:Stripe_Util_Set:private] => Array
                (
                )

        )

    [_transientValues:protected] => Stripe_Util_Set Object
        (
            [_elts:Stripe_Util_Set:private] => Array
                (
                )

        )

    [_retrieveOptions:protected] => Array
        (
        )

)


?>
//date picker start

if (top.location != location) {
    top.location.href = document.location.href ;
}


//date picker end


//datetime picker start


//datetime picker end

//timepicker start


//timepicker end

//colorpicker start



//colorpicker end

//multiselect start



//multiselect end


//spinner start

//spinner end



//wysihtml5 start

$('.wysihtml5').wysihtml5();

//wysihtml5 end


//tag input


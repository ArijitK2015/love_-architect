		<!------------------- for scroll to top ----------------------->
		<a href="#top" id="toTop"></a>
		<!------------------- scroll to top end ----------------------->
		
		
		<script class="include" type="text/javascript" src="<?php echo assets_url(); ?>admin/js/jquery.dcjqaccordion.2.7.js"></script>
		<script src="<?php echo assets_url(); ?>admin/js/jquery.scrollTo.min.js"></script>
		<script src="<?php echo assets_url(); ?>admin/js/jquery.nicescroll.js"></script>
		
		<script type="text/javascript" src="<?php echo assets_url(); ?>admin/js/bootstrap-fileupload/bootstrap-fileupload.js"></script>
		
		<script src="<?php echo assets_url();?>admin/js/skycons/skycons.js"></script>
		<script src="<?php echo assets_url();?>admin/js/jquery.easing.min.js"></script>
		<script src="<?php echo assets_url();?>admin/js/calendar/clndr.js"></script>
		
		<!--clock init-->
		<script src="<?php echo assets_url();?>admin/js/css3clock/js/css3clock.js"></script>
		
		<script src="<?php echo assets_url();?>admin/js/jquery.customSelect.min.js" ></script>
		
		<!--dynamic table-->
		<script type="text/javascript" language="javascript" src="<?php echo assets_url();?>admin/js/advanced-datatable/js/jquery.dataTables.js"></script>
		<script type="text/javascript" src="<?php echo assets_url();?>admin/js/data-tables/DT_bootstrap.js"></script>
		
		<script type="text/javascript" src="<?php echo assets_url();?>admin/js/ckeditor/ckeditor.js"></script>
		
		<!--common script init for all pages-->
		<script src="<?php echo assets_url();?>admin/js/scripts.js"></script>
		<!--<script src="<?php echo assets_url();?>admin/js/toggle-init.js"></script>
		<script src="<?php echo assets_url();?>admin/js/advanced-form.js"></script>-->
		
		<!--dynamic table initialization -->
		<script src="<?php echo assets_url();?>admin/js/dynamic_table_init.js"></script>
		
		<script type="text/javascript" src="<?php echo assets_url();?>admin/js/jquery.validate.min.js"></script>
		<script src="<?php echo assets_url();?>admin/js/validation-init.js"></script>
		<script src="<?php echo assets_url();?>admin/js/additional-methods.min.js"></script>
		
		
		
		<!--<div class="page_load">Page rendered in <strong>{elapsed_time}</strong> seconds. </div>-->
	</body>
</html>